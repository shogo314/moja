`ecottea`さんの提出で気づいたのですが、
[EDPC-Q](https://atcoder.jp/contests/dp/tasks/dp_q)で既出でした。